<div align="center">

<a href="https://vuicons.qiboz.top/" target="_blank">
  <img src="./assets/logo.png" width="120" alt="VU-Icons Logo" />
</a>

# VU-Icons

[![Website](https://img.shields.io/badge/Website-vuicons.qiboz.top-blue)](https://vuicons.qiboz.top/)
![npm version](https://img.shields.io/npm/v/vu-icons)
![npm downloads](https://img.shields.io/npm/dm/vu-icons)
![license](https://img.shields.io/npm/l/vu-icons)
![bundle size](https://img.shields.io/bundlephobia/minzip/vu-icons)

Vue3 & UniApp SVG Icon Library, supports Tree Shaking for on-demand imports, built-in complete TypeScript type declarations.

[English](./README.md) | [简体中文](./README.zh-CN.md)

</div>

[Website(https://vuicons.qiboz.top/)](https://vuicons.qiboz.top/)

## ✨ Features

- 🎨 **Dual Framework Support** - Supports both Vue3 and UniApp
- 📦 **On-demand Import** - Supports Tree Shaking optimization, only bundles used icons
- 🎯 **Icon Font** - Uses iconfont approach, small size, fast loading
- 🌈 **Highly Customizable** - Supports custom size and color
- 📝 **TypeScript** - Complete type declarations, excellent developer experience
- 🚀 **Automated Build** - One-click component generation, quickly add new icons
- 📱 **Responsive Design** - Supports both number and string sizes
- 🔧 **Mini Program Support** - Fully compatible with WeChat Mini Programs (uses icon font approach)

## 📦 Installation

```bash
npm install vu-icons
```

Or using yarn:

```bash
yarn add vu-icons
```

## 🚀 Quick Start

### Vue3 Project

```vue
<script setup lang="ts">
import { VuUser, VuSearch, VuStar } from 'vu-icons'
</script>

<template>
  <div>
    <VuUser :size="24" color="#333" />
    <VuSearch :size="32" color="#1890ff" />
    <VuStar :size="20" color="#faad14" />
  </div>
</template>
```

### UniApp Project

```vue
<script setup lang="ts">
import { VuUser, VuSearch, VuStar } from 'vu-icons/uniapp'
</script>

<template>
  <view>
    <VuUser :size="24" color="#333" />
    <VuSearch :size="32" color="#1890ff" />
    <VuStar :size="20" color="#faad14" />
  </view>
</template>
```

> **WeChat Mini Program Setup**: When using UniApp for WeChat Mini Programs, additional font configuration is required:
>
> 1. Copy `vu-icons.woff2` and `vu-icons.css` from `node_modules/vu-icons/dist/font/` to your project's `static/fonts/` directory
> 2. Import the CSS in `App.vue`:
> ```vue
> <style>
> @import './static/fonts/vu-icons.css';
> </style>
> ```

## 📖 Props

| Prop | Type | Default | Description |
|------|------|---------|------|
| size | number \| string | 24 | Icon size, supports number (px) or string (e.g., '2rem', '24px') |
| color | string | 'currentColor' | Icon color, supports any valid CSS color value |
| className | string | '' | Custom class name |
| spin | boolean | false | Whether to spin the icon, useful for loading states |

## 💡 IDE Support

VU-Icons provides enhanced support for modern IDEs (like WebStorm, VS Code).

- **Autocompletion**: Includes `web-types.json` for better component tag and prop suggestions.
- **Icons List**: A JSON file containing all icon names is available at `vu-icons/dist/icons.json` for dynamic usage.

```javascript
// Example: Importing icon list
import icons from 'vu-icons/dist/icons.json'

console.log(icons) // ['VuAdd', 'VuUser', ...]
```

## 🎨 Usage Examples

### Loading Icon

```vue
<template>
  <div>
    <VuLoading :size="24" color="#1890ff" spin />
    <!-- Or make any icon spin -->
    <VuRefresh :size="24" spin />
  </div>
</template>
```

### Custom Size

```vue
<template>
  <div>
    <VuUser :size="16" color="#333" />
    <VuUser :size="24" color="#333" />
    <VuUser :size="32" color="#333" />
    <VuUser :size="48" color="#333" />
  </div>
</template>
```

### Custom Color

```vue
<template>
  <div>
    <VuUser :size="32" color="#1890ff" />
    <VuUser :size="32" color="#52c41a" />
    <VuUser :size="32" color="#faad14" />
    <VuUser :size="32" color="#f5222d" />
  </div>
</template>
```

### String Size

```vue
<template>
  <div>
    <VuUser size="1rem" color="#722ed1" />
    <VuUser size="2rem" color="#722ed1" />
    <VuUser size="3rem" color="#722ed1" />
  </div>
</template>
```

### With CSS Class

```vue
<template>
  <div>
    <VuUser :size="24" color="#333" className="icon-hover" />
  </div>
</template>

<style>
.icon-hover:hover {
  opacity: 0.7;
  cursor: pointer;
}
</style>
```

## 📋 Available Icons

For more icons, please check [ICONS](https://vuicons.qiboz.top/)

## 🛠️ Development

### Adding New Icons

1. **Prepare SVG File**
   - Put SVG file in `src/icons/` directory
   - Use `kebab-case` naming (e.g., `home.svg`, `settings.svg`)
   - Ensure SVG has 24x24 viewBox

2. **Build Project**
   ```bash
   npm run build
   ```

3. **Use New Icon**
   ```vue
   <script setup>
   import { VuNewIcon } from 'vu-icons'
   </script>
   
   <template>
     <VuNewIcon :size="24" color="#333" />
   </template>
   ```

### Project Structure

```
vu-icons/
├── src/
│   ├── icons/              # Original SVG icons
│   ├── components/         # Component templates and generated components
│   ├── build-components.ts # Component generation script
│   └── index.ts           # Entry file
├── examples/              # Example projects
├── scripts/              # Build scripts
├── dist/                # Build output (published to npm)
├── gulpfile.js          # Gulp build configuration
├── package.json         # Project configuration
└── README.md           # Project documentation
```

### Local Development

```bash
# Install dependencies
npm install

# Setup demos (install dependencies for examples)
npm run setup:demos

# Generate components (required before running demos)
npm run build:components

# Run Vue3 Demo
npm run dev:vue3

# Run UniApp Demo
npm run dev:uniapp

# Build project
npm run build

# Lint check
npm run lint
```

## 📝 Changelog

Check [CHANGELOG.md](./CHANGELOG.md) for version update history.

## 📄 License

[MIT](./LICENSE)

## 🤝 Contributing

Contributions are welcome! If you have good suggestions or found bugs, feel free to submit Issues or Pull Requests.

## 📚 Related Documentation

- [ICONS.md](./ICONS.md) - Complete icon list and usage guide
- [CHANGELOG.md](./CHANGELOG.md) - Version update log

## ❓ FAQ

### Q: Why choose inline SVG instead of font icons?

A: Inline SVG has the following advantages:
- Better performance, no extra HTTP requests
- Supports on-demand import, reduces bundle size
- More flexible style control
- Better accessibility

### Q: How to use in Vue 2?

A: This component library only supports Vue3. If you need a Vue2 version, consider using other icon libraries.

### Q: Can I customize icon styles?

A: Yes! Add custom class names through `className` prop, or modify component styles directly.

### Q: Which platforms are supported?

A: Supports Vue3 and UniApp, can be used on Web, Mini Programs, Apps, and other platforms.

## 🌟 Star History

If this project helps you, please give it a Star to support!

<div align="center">

Made with ❤️ by [Qiboz](https://vuicons.qiboz.top/)

</div>
